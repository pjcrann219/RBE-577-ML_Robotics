For Training:
1. Activate in conda the enviroment.yml file 
2. To train, place the images and their labeled bounding box information into the train and val folders
3. Download the yolo11m.pt pre trained model and place in the main folder
4. run train.py

For Inference
1. Activate in conda the enviroment.yml file 
2. Place the images you want to classify into inferences/images
3. run inference.py
